<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Define all the restore steps that will be used by the restore_moochat_activity_task
 *
 * @package    mod_moochat
 * @copyright  2025 Brian A. Pool
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_moochat';
$plugin->version = 2025103009;  // YYYYMMDDXX - Converted to Templates and Output API
$plugin->requires = 2022041900; // Moodle 4.0
$plugin->maturity = MATURITY_BETA;
$plugin->release = 'v1.2.2';
